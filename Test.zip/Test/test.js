var _$ = require('../dist/src/mixed.min.js');

console.log(_$)
